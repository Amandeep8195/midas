<?php
/**
 * Template for displaying Author Archive pages
 *
 * @package WordPress
 * @subpackage Midas_Touch
 * @since Midas Touch 1.0
 */

get_header(); ?>

		<div id="container">
			<div id="content" role="main">

<?php
	/*
	 * Queue the first post, that way we know who
	 * the author is when we try to get their name,
	 * URL, description, avatar, etc.
	 *
	 * We reset this later so we can run the loop
	 * properly with a call to rewind_posts().
	 */
if ( have_posts() ) {
	the_post();
}
?>

				<h1 class="page-title author">
				<?php
				/* translators: %s: Author display name. */
				printf( __( 'Author Archives: %s', 'midastouch' ), '<span class="vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" rel="me">' . get_the_author() . '</a></span>' );
				?>
				</h1>

<?php
// If a user has filled out their description, show a bio on their entries.
if ( get_the_author_meta( 'description' ) ) :
	?>
					<div id="entry-author-info">
						<div id="author-avatar">
							<?php
							/**
							 * Filters the Midas Touch author bio avatar size.
							 *
							 * @since Midas Touch 1.0
							 *
							 * @param int The height and width avatar dimensions in pixels. Default 60.
							 */
							$author_bio_avatar_size = apply_filters( 'midastouch_author_bio_avatar_size', 60 );
							echo get_avatar( get_the_author_meta( 'user_email' ), $author_bio_avatar_size );
							?>
						</div><!-- #author-avatar -->
						<div id="author-description">
							<h2>
							<?php
							/* translators: %s: Author display name. */
							printf( __( 'About %s', 'midastouch' ), get_the_author() );
							?>
							</h2>
							<?php the_author_meta( 'description' ); ?>
						</div><!-- #author-description	-->
					</div><!-- #entry-author-info -->
<?php endif; ?>

<?php
	/*
	 * Since we called the_post() above, we need
	 * to rewind the loop back to the beginning.
	 * That way we can run the loop properly, in full.
	 */
	rewind_posts();

	/*
	 * Run the loop for the author archive page to output the authors posts
	 * If you want to overload this in a child theme then include a file
	 * called loop-author.php and that will be used instead.
	 */
	get_template_part( 'loop', 'author' );
?>
			</div><!-- #content -->
		</div><!-- #container -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
